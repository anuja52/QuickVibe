import csv
import io
from datetime import date, timedelta

from flask import (
    Flask,
    flash,
    g,
    redirect,
    render_template,
    request,
    url_for,
    make_response,
)

from db import get_db, init_db

app = Flask(__name__)
app.secret_key = "quickvibe-secret-key-2024"


# ---------------------------------------------------------------------------
# DB lifecycle
# ---------------------------------------------------------------------------

def _db():
    if "db" not in g:
        g.db = get_db()
    return g.db


@app.teardown_appcontext
def close_db(exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


# ---------------------------------------------------------------------------
# Page 1 – Dashboard / Daily Check-in Board
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    db = _db()
    today = date.today().isoformat()
    habits = db.execute(
        """
        SELECT h.*,
               (SELECT 1 FROM check_ins c WHERE c.habit_id = h.id AND c.check_date = ?) AS done_today
        FROM habits h
        ORDER BY h.category, h.title
        """,
        (today,),
    ).fetchall()
    return render_template("index.html", habits=habits, today=today)


# ---------------------------------------------------------------------------
# Toggle – mark/unmark a habit complete for today
# ---------------------------------------------------------------------------

@app.route("/toggle/<int:habit_id>", methods=["POST"])
def toggle(habit_id):
    db = _db()
    today = date.today()
    today_str = today.isoformat()
    yesterday_str = (today - timedelta(days=1)).isoformat()

    habit = db.execute("SELECT * FROM habits WHERE id = ?", (habit_id,)).fetchone()
    if not habit:
        flash("Habit not found.", "danger")
        return redirect(url_for("index"))

    already_done = db.execute(
        "SELECT 1 FROM check_ins WHERE habit_id = ? AND check_date = ?",
        (habit_id, today_str),
    ).fetchone()

    if already_done:
        # Toggle OFF – remove today's check-in and decrement streak
        db.execute(
            "DELETE FROM check_ins WHERE habit_id = ? AND check_date = ?",
            (habit_id, today_str),
        )
        new_streak = max(0, habit["current_streak"] - 1)
        new_last = yesterday_str if new_streak > 0 else None
        db.execute(
            "UPDATE habits SET current_streak = ?, last_completed = ? WHERE id = ?",
            (new_streak, new_last, habit_id),
        )
        db.commit()
        flash(f"'{habit['title']}' unmarked for today.", "warning")
    else:
        # Toggle ON
        db.execute(
            "INSERT OR IGNORE INTO check_ins (habit_id, check_date) VALUES (?, ?)",
            (habit_id, today_str),
        )
        last_completed = habit["last_completed"]
        if last_completed == yesterday_str:
            new_streak = habit["current_streak"] + 1
        else:
            new_streak = 1

        new_best = max(habit["best_streak"], new_streak)
        db.execute(
            """UPDATE habits
               SET current_streak = ?, best_streak = ?, last_completed = ?
               WHERE id = ?""",
            (new_streak, new_best, today_str, habit_id),
        )
        db.commit()
        flash(f"🔥 '{habit['title']}' marked complete! Streak: {new_streak} days.", "success")

    return redirect(url_for("index"))


# ---------------------------------------------------------------------------
# Page 2 – Add Habit Form
# ---------------------------------------------------------------------------

@app.route("/add-habit", methods=["GET", "POST"])
def add_habit():
    categories = ["Study", "Coding", "Fitness", "Routine"]
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "Routine")
        goal_note = request.form.get("goal_note", "").strip()

        if not title:
            flash("Habit title is required.", "danger")
            return render_template("add_habit.html", categories=categories)

        if category not in categories:
            category = "Routine"

        db = _db()
        db.execute(
            "INSERT INTO habits (title, category, goal_note) VALUES (?, ?, ?)",
            (title, category, goal_note),
        )
        db.commit()
        flash(f"✅ Habit '{title}' created successfully!", "success")
        return redirect(url_for("index"))

    return render_template("add_habit.html", categories=categories)


# ---------------------------------------------------------------------------
# Page 3 – Habit Detail / History / Delete
# ---------------------------------------------------------------------------

@app.route("/habit/<int:habit_id>")
def detail(habit_id):
    db = _db()
    habit = db.execute("SELECT * FROM habits WHERE id = ?", (habit_id,)).fetchone()
    if not habit:
        flash("Habit not found.", "danger")
        return redirect(url_for("index"))

    history = db.execute(
        "SELECT check_date FROM check_ins WHERE habit_id = ? ORDER BY check_date DESC",
        (habit_id,),
    ).fetchall()

    # Build a set of completed date strings for calendar rendering
    completed_dates = {row["check_date"] for row in history}

    # Generate last 30 days for mini-calendar
    today = date.today()
    calendar_days = [(today - timedelta(days=i)).isoformat() for i in range(29, -1, -1)]

    return render_template(
        "detail.html",
        habit=habit,
        history=history,
        completed_dates=completed_dates,
        calendar_days=calendar_days,
    )


@app.route("/habit/<int:habit_id>/delete", methods=["POST"])
def delete_habit(habit_id):
    db = _db()
    habit = db.execute("SELECT title FROM habits WHERE id = ?", (habit_id,)).fetchone()
    if habit:
        db.execute("DELETE FROM habits WHERE id = ?", (habit_id,))
        db.commit()
        flash(f"🗑️ Habit '{habit['title']}' and all its history have been deleted.", "info")
    else:
        flash("Habit not found.", "danger")
    return redirect(url_for("index"))


# ---------------------------------------------------------------------------
# Page 4 – Analytics
# ---------------------------------------------------------------------------

@app.route("/analytics")
def analytics():
    db = _db()

    total_habits = db.execute("SELECT COUNT(*) as c FROM habits").fetchone()["c"]
    total_checkins = db.execute("SELECT COUNT(*) as c FROM check_ins").fetchone()["c"]
    best_row = db.execute(
        "SELECT title, best_streak FROM habits ORDER BY best_streak DESC LIMIT 1"
    ).fetchone()
    best_streak_habit = best_row["title"] if best_row else "—"
    best_streak_val = best_row["best_streak"] if best_row else 0

    habits_for_chart = db.execute(
        "SELECT id, title, current_streak, best_streak, category FROM habits ORDER BY best_streak DESC"
    ).fetchall()

    # Category totals
    category_counts = db.execute(
        """
        SELECT h.category, COUNT(c.id) as total
        FROM habits h
        LEFT JOIN check_ins c ON c.habit_id = h.id
        GROUP BY h.category
        ORDER BY total DESC
        """
    ).fetchall()

    # 7-day activity
    week_activity = []
    for i in range(6, -1, -1):
        d = (date.today() - timedelta(days=i)).isoformat()
        cnt = db.execute(
            "SELECT COUNT(*) as c FROM check_ins WHERE check_date = ?", (d,)
        ).fetchone()["c"]
        week_activity.append({"date": d, "count": cnt})

    return render_template(
        "analytics.html",
        total_habits=total_habits,
        total_checkins=total_checkins,
        best_streak_habit=best_streak_habit,
        best_streak_val=best_streak_val,
        habits_for_chart=habits_for_chart,
        category_counts=category_counts,
        week_activity=week_activity,
    )


# ---------------------------------------------------------------------------
# Page 5 – Export / CSV
# ---------------------------------------------------------------------------

@app.route("/export")
def export():
    db = _db()
    records = db.execute(
        """
        SELECT c.check_date, h.title, h.category
        FROM check_ins c
        JOIN habits h ON h.id = c.habit_id
        ORDER BY c.check_date DESC
        LIMIT 30
        """
    ).fetchall()
    return render_template("export.html", records=records)


@app.route("/export-csv")
def export_csv():
    db = _db()
    rows = db.execute(
        """
        SELECT c.check_date, h.title, h.category, h.current_streak, h.best_streak
        FROM check_ins c
        JOIN habits h ON h.id = c.habit_id
        ORDER BY c.check_date DESC
        """
    ).fetchall()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Date", "Habit", "Category", "Current Streak", "Best Streak"])
    for row in rows:
        writer.writerow([row["check_date"], row["title"], row["category"],
                         row["current_streak"], row["best_streak"]])

    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=quickvibe_export.csv"
    response.headers["Content-Type"] = "text/csv"
    return response


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
