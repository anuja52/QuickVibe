import sqlite3
from datetime import date, timedelta

DB_PATH = "quickvibe.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS habits (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            title           TEXT    NOT NULL,
            category        TEXT    NOT NULL DEFAULT 'Routine',
            goal_note       TEXT,
            current_streak  INTEGER NOT NULL DEFAULT 0,
            best_streak     INTEGER NOT NULL DEFAULT 0,
            last_completed  DATE,
            created_at      DATE    NOT NULL DEFAULT (DATE('now'))
        );

        CREATE TABLE IF NOT EXISTS check_ins (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            habit_id    INTEGER NOT NULL REFERENCES habits(id) ON DELETE CASCADE,
            check_date  DATE    NOT NULL,
            UNIQUE(habit_id, check_date)
        );
        """
    )
    conn.commit()

    # Only seed if habits table is empty
    row = cur.execute("SELECT COUNT(*) as c FROM habits").fetchone()
    if row["c"] == 0:
        _seed(conn, cur)

    conn.close()


def _seed(conn, cur):
    today = date.today()

    seed_habits = [
        {
            "title": "2 Hours Java & DSA Practice",
            "category": "Coding",
            "goal_note": "Solve 2 LeetCode problems + 1 topic revision daily",
            "streak_days": 7,
        },
        {
            "title": "MCA CET Revision",
            "category": "Study",
            "goal_note": "Cover 3 chapters daily from previous year papers",
            "streak_days": 5,
        },
        {
            "title": "30-Min Cardio",
            "category": "Fitness",
            "goal_note": "Running or skipping rope before breakfast",
            "streak_days": 3,
        },
    ]

    for habit in seed_habits:
        n = habit["streak_days"]
        # last_completed is today
        last_completed = today.isoformat()
        cur.execute(
            """
            INSERT INTO habits
                (title, category, goal_note, current_streak, best_streak, last_completed, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                habit["title"],
                habit["category"],
                habit["goal_note"],
                n,
                n,
                last_completed,
                (today - timedelta(days=n + 1)).isoformat(),
            ),
        )
        habit_id = cur.lastrowid

        # Insert consecutive check-in dates up to and including today
        for i in range(n):
            d = today - timedelta(days=(n - 1 - i))
            cur.execute(
                "INSERT OR IGNORE INTO check_ins (habit_id, check_date) VALUES (?, ?)",
                (habit_id, d.isoformat()),
            )

    conn.commit()
